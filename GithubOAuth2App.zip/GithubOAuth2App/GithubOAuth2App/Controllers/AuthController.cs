﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;

namespace GithubOAuth2App.Controllers
{
    
    [Route("[controller]/[action]")]
    public class AuthController : Controller
    {
        [HttpGet]
        public IActionResult Login(string returnUrl = "/")
        {
            //make other API calls after received the token from GitHub
            return Challenge(new AuthenticationProperties() { RedirectUri = returnUrl });
            
        }
    }
}
