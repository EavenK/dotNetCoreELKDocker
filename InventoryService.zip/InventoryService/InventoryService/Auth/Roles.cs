﻿namespace InventoryService.Auth
{
    public class Roles
    {
        public const string Admin = "Admin";
        public const string User = "User";

    }
}
