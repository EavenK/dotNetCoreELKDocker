﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace InventoryService.Contexts
{
    public class AuthenticationIdentityContext:IdentityDbContext<IdentityUser>
    {

        public AuthenticationIdentityContext(DbContextOptions<AuthenticationIdentityContext> options) : base(options) 
        {
            this.Database.EnsureCreated();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }
}
