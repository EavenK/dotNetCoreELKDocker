﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventoryService.Models
{
    [Table("Product")]
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("Product_id")]
        public long ProductId { get; set; }

        [Column("Name")]
        public string? Name { get; set; }

        //create as value object, not table
        public ProductDescription? ProductDescription { get; set; }
        public string? SKU { get; set; }


        [ForeignKey("Category")]
        [Column("Category_Id_FK")]  //only this column will be created 
        public long CategoryId { get; set; } //this is the type only Category_Id_FK
        public Category? Category { get; set; } //this is the type only for [ForeignKey("Category")]

    }
}
