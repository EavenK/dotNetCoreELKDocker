﻿using GraphQL.Types;
using InventoryService.Mutations;
using InventoryService.Queries;
using Microsoft.Identity.Client;

namespace InventoryService.Schemas
{
    public class CategorySchema:Schema
    {

        public CategorySchema(IServiceProvider ServiceProvider) {

            Query = ServiceProvider.GetRequiredService<RootQuery>();
            //Query = ServiceProvider.GetRequiredService<ProductGLQuery>();

            Mutation = ServiceProvider.GetRequiredService<RootMutation>();

        }

    }
}
