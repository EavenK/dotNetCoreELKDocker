﻿namespace InventoryService.Models
{
    public class LdapConfig
    {
        public string? Path { get; set; }
        public string? UserDomainName { get; set; }
    }
}
